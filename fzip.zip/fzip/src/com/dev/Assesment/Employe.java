package com.dev.Assesment;

//This is a enpacsulated class with only getters and setters
//which 

public class Employe {
	
	private int empid;
	private String ename;
	@Override
	public String toString() {
		return "Employe [empid=" + empid + ", ename=" + ename + ", email=" + email + ", password=" + password
				+ ", salary=" + salary + "]";
	}
	private String email;
	private int password;
	private double salary;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPassword() {
		return password;
	}
	public void setPassword(int password) {
		this.password = password;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	

}

package com.dev.Assesment;
import java.util.HashMap;

public class Emp_impli implements Emp_interface {
	
	static HashMap<String,Employe> hm = new HashMap<String,Employe>();

	public static void main(String[] args) {
		
	
	}

	@Override
	public boolean putData(String key, Employe data) {
		if( data != null) {
			hm.put(key, data);
			System.out.println("output of put() is "+ hm);
			
			return true;	
		}
		return false;
		
	}


	@Override
	public void removedata(String key) {
		hm.remove(key);
		System.out.println("Data present in hashmap after remove() is"+ hm);
		
	}

	@Override
	public Employe getdata(String key) {
		
		return hm.get(key);
	
	}

}

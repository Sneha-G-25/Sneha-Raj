package com.dev.Assesment;

public class Emp_data extends Employe{
	
	
public static void main(String[] args) {
		
	Emp_impli impli = new Emp_impli();
	
	Emp_data e = new Emp_data();
	Emp_data e1 = new Emp_data();
	Emp_data e2 = new Emp_data();
	
	e.setEname("Sneha");
	e.setEmpid(01);
	e.setEmail("Sneha@gmail.com");
	e.setPassword(78775);
	e.setSalary(6223.76);
	
	e1.setEname("Suma");
	e1.setEmpid(02);
	e1.setEmail("Suma@gmail.com");
	e1.setPassword(23554);
	e1.setSalary(5723.76);
	
	e2.setEname("neha");
	e2.setEmpid(03);
	e2.setEmail("neha@gmail.com");
	e2.setPassword(23554);
	e2.setSalary(5723.76);
	
	e2.setEname("Bhuvan");		// updating the value
	
	boolean r1 = impli.putData("1",e);	// craeting the object of implimentation class
	System.out.println( r1);
	boolean r2 = impli.putData("2", e1);
	boolean r3 = impli.putData("3",e2);
	
	
	impli.getdata("1");		//calling the getData() 
	
	impli.removedata("2");	// calling the removeData()
	
	
	}

	

}

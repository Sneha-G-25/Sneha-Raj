package com.dev.Assesment;

public interface Emp_interface {
	
	public boolean putData(String key ,Employe data);
	public void removedata(String key);
	public Employe getdata(String key);

}
